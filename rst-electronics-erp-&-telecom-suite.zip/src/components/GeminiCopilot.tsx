import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, Sparkles, RefreshCw } from 'lucide-react';
import { SoundEngine } from '../utils/erpHelpers';

interface GeminiCopilotProps {
  lang: 'en' | 'bn' | 'ar';
  businessName: string;
}

export const GeminiCopilot: React.FC<GeminiCopilotProps> = ({ lang, businessName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    {
      role: 'model',
      text:
        lang === 'bn'
          ? `আসসালামু আলাইকুম! আমি ${businessName}-এর জেমিনি এআই সহকারী। স্টক, ওমান টেলিকম প্রফিট মার্জিন, বিক্রয় রিপোর্ট বা ভিআইপি কাস্টমার সম্পর্কে যেকোনো প্রশ্ন করুন!`
          : lang === 'ar'
          ? `مرحباً بك! أنا المساعد الذكي لنظام ${businessName}. اسألني عن المبيعات، المخزون، أرباح الاتصالات، أو عملاء VIP!`
          : `Welcome! I am the ${businessName} Gemini AI Copilot. Ask me about Oman Telecom margins, IMEI stock levels, net profit, or VIP customer segments.`,
    },
  ]);

  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const sendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt ?? input).trim();
    if (!textToSend || loading) return;

    SoundEngine.click();
    const updatedMessages = [...messages, { role: 'user' as const, text: textToSend }];
    setMessages(updatedMessages);
    if (!customPrompt) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: updatedMessages,
          lang,
        }),
      });
      const data = await res.json();
      if (data.error) {
        setMessages((prev) => [...prev, { role: 'model', text: `Error: ${data.error}` }]);
      } else {
        SoundEngine.notify();
        setMessages((prev) => [...prev, { role: 'model', text: data.reply }]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        { role: 'model', text: `Connection error: ${err?.message || 'Unable to reach AI server'}` },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {isOpen ? (
        <div className="w-80 sm:w-96 h-[500px] rounded-2xl border border-slate-200 bg-white shadow-2xl flex flex-col overflow-hidden">
          <div className="flex items-center justify-between bg-slate-900 px-4 py-3 text-white">
            <div className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-emerald-400" />
              <div>
                <div className="text-xs font-bold">{businessName} AI Copilot</div>
                <div className="text-[10px] text-slate-400">Powered by Server-Side Gemini 3.8 Flash</div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="flex gap-1.5 overflow-x-auto border-b border-slate-100 bg-slate-50 px-3 py-2">
            {[
              'Analyze Oman Telecom profit margins',
              'Which VIP customers spent the most?',
              'Check low stock & IMEI items',
            ].map((q) => (
              <button
                key={q}
                onClick={() => sendMessage(q)}
                className="rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:border-emerald-500 hover:text-emerald-700 whitespace-nowrap shrink-0"
              >
                {q}
              </button>
            ))}
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-3.5 space-y-3 bg-slate-50/50">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`max-w-[88%] rounded-xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-wrap ${
                  m.role === 'user'
                    ? 'ml-auto bg-emerald-600 text-white'
                    : 'bg-white border border-slate-200 text-slate-800'
                }`}
              >
                {m.text}
              </div>
            ))}
            {loading && (
              <div className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs text-slate-500">
                <RefreshCw className="h-3.5 w-3.5 animate-spin text-emerald-600" />
                <span>Analyzing live ERP telemetry...</span>
              </div>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage();
            }}
            className="border-t border-slate-200 bg-white p-2.5 flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                lang === 'bn'
                  ? 'স্টক, লাভ বা টেলিকম সম্পর্কে প্রশ্ন করুন...'
                  : lang === 'ar'
                  ? 'اسأل عن المبيعات أو المخزون...'
                  : 'Ask about sales, telecom margin, IMEI...'
              }
              className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading}
              className="rounded-lg bg-emerald-600 p-2 text-white hover:bg-emerald-700 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      ) : (
        <button
          onClick={() => {
            SoundEngine.click();
            setIsOpen(true);
          }}
          className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-4 py-3 text-xs font-semibold text-white shadow-xl hover:bg-emerald-600 transition-all"
        >
          <Sparkles className="h-4 w-4 text-amber-400" />
          <span>Gemini ERP Copilot</span>
        </button>
      )}
    </div>
  );
};
